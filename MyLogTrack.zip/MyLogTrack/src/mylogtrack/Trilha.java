/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mylogtrack;

import java.util.ArrayList;

/**
 *
 * @author alunopa
 */
public class Trilha {
    
    
    private float distanciaTotal;
    private int pontuacao;
    private String grauDificuldade;
    private String localizacao;
    
    private ArrayList<Amigo> Amigos;
    private ArrayList<Guia> guias;
    private ArrayList<Familia> familiares;

    public float getDistanciaTotal() {
        return distanciaTotal;
    }

    public void setDistanciaTotal(float distanciaTotal) {
        this.distanciaTotal = distanciaTotal;
    }

    

    public String getGrauDificuldade() {
        return grauDificuldade;
    }

    public void setGrauDificuldade(String grauDificuldade) {
        this.grauDificuldade = grauDificuldade;
    }

    public String getLocalizacao() {
        return localizacao;
    }

    public void setLocalizacao(String localizacao) {
        this.localizacao = localizacao;
    }

    public ArrayList<Amigo> getAmigos() {
        return Amigos;
    }

    public void setAmigos(ArrayList<Amigo> Amigos) {
        this.Amigos = Amigos;
    }

    public ArrayList<Guia> getGuias() {
        return guias;
    }

    public void setGuias(ArrayList<Guia> guias) {
        this.guias = guias;
    }

    public ArrayList<Familia> getFamiliares() {
        return familiares;
    }

    public void setFamiliares(ArrayList<Familia> familiares) {
        this.familiares = familiares;
    }
    
    public int calculaPontuacaoPorFamiliares(){
        int pontuacaoFamilia = 0;
        pontuacaoFamilia = this.familiares.size() * 20;
        for(int i = 0; i < this.familiares.size(); i++){
            if(this.familiares.get(i).getIdade() < 18){
                this.pontuacao +=  10;
            }
        }
        return pontuacaoFamilia;
        
    }
    public int calculaPontuacaoPorAmigos(){
        int pontuacaoAmigos = 0;
        pontuacaoAmigos = this.Amigos.size() * 15;
        for(int i = 0; i < this.Amigos.size(); i++){
            if(this.Amigos.get(i).getIdade()< 18){
                pontuacaoAmigos +=  10;
            }
        }
        return pontuacaoAmigos;
    }
    public int calculaPontuacaoPorGuia(){
        int pontuacaoGuia = 0;
        pontuacaoGuia = this.Amigos.size() * -5;
        return pontuacaoGuia;
    }
    
    public int getPontuacao() {
        return pontuacao;
    }

    public void setPontuacao() {
        calculaPontuacaoPorFamiliares();
        calculaPontuacaoPorAmigos();
        calculaPontuacaoPorGuia();
        if(this.familiares.size() + this.Amigos.size() + this.guias.size() > 10){
            this.pontuacao -= 5;
        }
    }
    
    
    
    
    
}
